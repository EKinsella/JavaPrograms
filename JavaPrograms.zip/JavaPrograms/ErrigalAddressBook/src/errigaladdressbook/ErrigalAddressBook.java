/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errigaladdressbook;

import javax.swing.JOptionPane;

/**
 *
 * @author EPKinsella
 */
public class ErrigalAddressBook {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AddressBook ab = new AddressBook();
            String input, s;
            int ch;
            while (true) 
            {
                input = JOptionPane.showInputDialog("Enter 1 to add " +"\n Enter 2 to Search \n Enter 3 to Delete" +"\n Enter 4 to Exit");
                ch = Integer.parseInt(input);
                switch (ch) {
                case 1:
                    ab.addPerson();
                    break;
                case 2:
                    s = JOptionPane.showInputDialog("Enter name to search");
                    ab.searchPerson(s);
                    break;
                case 3:
                    s = JOptionPane.showInputDialog("Enter name to delete ");
                    ab.deletePerson(s);
                    break;
                case 4:
                    s = JOptionPane.showInputDialog("Enter the name to edit");
                    ab.editPerson(s,s);
                    break;
                case 5: 
                    System.exit(0);
            }
        }//end whil
    }
}
