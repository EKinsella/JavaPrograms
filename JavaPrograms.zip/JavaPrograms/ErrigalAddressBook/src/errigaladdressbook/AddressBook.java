/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errigaladdressbook;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowFilter.Entry;

/**
 *
 * @author EPKinsella
 */
class AddressBook {
    private static Object contactList;
    ArrayList persons;
    private Object Person;
    int personList[];
    //constructor
    public AddressBook ( ) {
        persons = new ArrayList();
    }
    //add new person record to arraylist after taking input
    public void addPerson( ) {
        String name = JOptionPane.showInputDialog("Enter name");
        String add = JOptionPane.showInputDialog("Enter address");
        String pNum = JOptionPane.showInputDialog("Enter phone no");
        //construt new person object
        PersonInfo p = new PersonInfo(name, add, pNum);
        //add the above PersonInfo object to arraylist
        persons.add(p);
    }
    //search person record by name by iterating over arraylist
    public void searchPerson (String n) 
    {
        for (int i=0; i< persons.size(); i++) 
        {
            PersonInfo p = (PersonInfo)persons.get(i);
            if ( n.equals(p.name) ) 
            {
                p.print();
            }
        } // end for
    } // end searchPerson 
    //delete person record by name by iterating over arraylist
    public void deletePerson (String n) 
    {
        for (int i=0; i< persons.size(); i++) 
        {
            PersonInfo p = (PersonInfo)persons.get(i);
            if ( n.equals(p.name) ) 
            {
                persons.remove(i);
            }
        }
    }

//    public void editPerson(String newContact, String replacedContact) {
//           
//            
//    }

//    void editPerson(String s) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    private int findContact(String replacedContact) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        for (int i=0; i< persons.size(); i++) 
        {
            PersonInfo p = (PersonInfo)persons.get(i);
            if ( replacedContact.equals(p.name) ) 
            {
                p.print();
            }
        } // end for
        return 0;
    }
    
//    public static void sortContactList() 
//    {
//        for (int i = 0; i < personList.length - 1; i++) 
//        {
//            for (int j = i + 1; i < personList.length; j++) {
//                if ((personList[j].first.toCharArray()[0]) < (personList[i].first.toCharArray()[0])) {
//                    int tmp = personList[j];
//                    personList[j] = personList[i];
//                    personList[i] = tmp;
//                }
//            }
//        }
//    }

    void editPerson(String newContact, String replacedContact) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         int index = findContact(replacedContact);
            if (index >= 0) {
                persons.set(findContact(replacedContact), newContact);
            } else {
            System.out.println("No such contact found to update");
            }
    }
    
}
