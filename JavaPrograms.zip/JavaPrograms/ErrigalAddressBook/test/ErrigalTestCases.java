/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author EPKinsella
 */
public class ErrigalTestCases {
    
    private PersonInfo sampleContact;
    
    public ErrigalTestCases() {
        sampleContact = new PersonInfo("Joe Bloggs", "USA", "089-1234567");
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    private static class PersonInfo {

        public PersonInfo() {
        }
        private String fName;
        private String lName;
        private String number;

        private PersonInfo(String fName, String lName, String number) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            if(fName == null) {
            fName = "";
        }
        if(lName == null) {
            lName = "";
        }
        if(number == null) {
            number = "";
        }

        this.fName = fName.trim();
        this.lName = lName.trim();
        this.number = number.trim();

        if(this.fName.length() == 0 && this.lName.length() == 0) {
            throw new IllegalStateException(
                      "Either the name or phone must not be blank.");
        }
        
        }
    }
}
