/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackernews;

import java.awt.event.*;
import java.io.*;
import java.net.*;
/**
 *
 * @author EPKinsella
 */
public class Hackernews {
    private static Object item;
    private static Object title;
    private static Object author;
    String url = "https://news.ycombinator.com/";
    String posts = "";
    int pages = (posts/30) + 1;
    
    for(int i = 0; i < pages.length; i++)
    private Object requests;
    {
        String r = requests.toString(url);
        String c = r.substring(pages);
    }
    public static int scrape(page, posts)
    {
        String table = "'table', 'itemlist'";
        String rows = "tr";                 

        String items = rows.toString();
        //[merge(row, rows[i+1]) for i, row in enumerate(rows) if row.get('class') == ['athing']]
        
        if((posts/30) + 1 == page)
            items = (posts % 30);

        for(String item:items)
        {
                String title = item.toString(".storylink");
                String uri = item.toString(".storylink");
                String rank = item.toString(".rank");
            try{
                String author  = item.toString("'td', 'subtext','a'");
                String points  = item.toString("'td', 'subtext','span'");
                String comments = item.toString("'td', 'subtext','a'");
            }
            catch{
                System.out.println('0');
            }
        }
        if(title.equals(0))
            title = "empty";
        if(author.equals(0))
            author = "empty";
        
        if(title.equals(256))
            title = Hackernews.title;
        if(author.equals(256))
            author = Hackernews.author;
        int points = 0;
        int comments = 0;
        //int rank;
        char rank = 0;
        
        if(points == 0) 
            System.out.println('0');
        else if(points< '0')
            System.out.println('0');
        else if(comments == 0)
            System.out.println('0');
        else if(rank == 0)
            System.out.println('0');
        else if(rank < '0') 
            System.out.println('0');
        return 0;
    }
    //System.out.println("points, pages");
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(scrape());
    }
}
