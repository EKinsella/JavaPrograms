/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author EPKinsella
 */
public class AddressBookJUnitTest {
    
    private Contact sampleContact;
    
    public AddressBookJUnitTest() 
    {
        sampleContact = new Contact("Joe", "Bloggs", "089-1234567");   
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        AddressBookJUnitTest aBook = new AddressBookJUnitTest();
        Iterable<Contact> contact = null;
        for(Contact details : contact) {
            aBook.addDetails(details);
        }
        Contact sampleDetails = null;
        // Take a copy of the details of one of the contacts.
        ContactDetails existingContact = new ContactDetails(sampleDetails.fName, sampleDetails.lName,sampleDetails.number);
        // Create a further contact who is not yet in the address book.
        ContactDetails furtherContact = new ContactDetails("andy", "coole", "0044282383579");
        // Change the address of an existing contact.
//        ContactDetails revisedDetails = new ContactDetails(existingContact.fName,
//                existingContact.lName,
//                existingContact.number + "X");
    }
    
    @After
    public void tearDown() {
        Object aBook = null;
        Object existingContact = null;
        Object furtherContact = null;
        Object revisedDetails = null;
    }

    private void Contact(String fname, String lname, String phone) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void addDetails(Contact details) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    private static class Contact {
        private String fName;
        private String lName;
        private String number;

        public Contact() {
        }

        private Contact(String fName, String lName, String number) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            if(fName == null) {
            fName = "";
        }
        if(lName == null) {
            lName = "";
        }
        if(number == null) {
            number = "";
        }

        this.fName = fName.trim();
        this.lName = lName.trim();
        this.number = number.trim();

        if(this.fName.length() == 0 && this.lName.length() == 0) {
            throw new IllegalStateException(
                      "Either the name or phone must not be blank.");
        }
        
        }
    }
}
