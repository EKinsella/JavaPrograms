/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addressbook;

/**
 *
 * @author EPKinsella
 */
class Contact {
    private String fName;
    private String lName;
    private String phoneNumber;
    Object first;
    
    public Contact(String fName, String lName, String phoneNumber)
    {
        this.fName = fName;
        this.lName = lName;
        this.phoneNumber = phoneNumber;
    }
    
    public String getFName()
    {
        return fName;
    }
    
    public void setName(String fName)
    {
        this.fName = fName;
    }
    public String getLName()
    {
        return lName;
    }
    
    public void setLName(String lName)
    {
        this.lName = lName;
    }
    public String getNumber()
    {
        return phoneNumber;
    }
    
    public void setNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    
    public String toString()
    {
        return fName + " , " +lName+ " , "+phoneNumber;
    }
}
