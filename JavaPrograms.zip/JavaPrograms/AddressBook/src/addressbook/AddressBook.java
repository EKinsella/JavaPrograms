/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addressbook;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author EPKinsella
 */
public class AddressBook {
    private static final Scanner keyboard = new Scanner(System.in);

    private static void addContact() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Enter first name: ");
        String fName = keyboard.nextLine();
        System.out.println("Enter last name: ");
        String lName = keyboard.nextLine();
        System.out.println("Enter number: ");
        String number = keyboard.nextLine();
        
        Contact contacts = new Contact(fName, lName, number);
        addToList(contacts);
        //contact.add(contacts);
        System.out.println("Contact added");
    }

    private static void editContact() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Enter the name to be edited");
        
    }

    public static void deleteContact() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //int index = 0;
        System.out.println("Enter the name to be deleted");
        String deletedContact = keyboard.nextLine();
        //Object index = 0;
        //contact.remove(deletedContact);
        System.out.println("Contact deleted");
    }

    public static void viewContacts() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //return contact.indexOf(cont);
        String contactName = keyboard.nextLine();
        //int index = contact.findContacts(contactName);
        //    if (index >= 0) {
        //System.out.println(contact.findContacts(contactName) + 1 + ") " + contactName);
        //    } else {
        System.out.println("No contact details found.");
    //}
        
    }

    private static void addToList(Contact contacts) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(file, true)))
        {
            writer.write(contacts.getFName() + " " + " "+contacts.getLName()+" " +contacts.getNumber());
        }
        catch(IOException e){
            System.out.println(e);
        }
    
    }

    public int findContacts() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return contact.indexOf(contact);
        //System.out.println("");
//        for (int i = 0; i < contact.size() - 1; i++) {
//            for (int j = i + 1; i < contact.size(); j++) {
//                if ((contact.get(j).first.toString().toCharArray()[0]) < (contact.get(i).first.toString().toCharArray()[0])) {
//                    //Entry tmp;
//                    Contact tmp = contact.get(j);
//                    contact.set(j, contact.get(i));
//                    contact.set(i, tmp);
//                }
//            }
//        }
    }

    private String name;
    private List<Contact> contact;
    private static File file = new File("addressbook.txt");
    
    public AddressBook()
    {
        this.name = name;
        this.contact = contact;
    }
    public String getName()
    {
        return name;
    }
    public List<Contact> getContact()
    {
        return contact;
    }
    public void setContact(List<Contact> contact)
    {
        this.contact = contact;
    }
    
    public static Set<Contact> getContactList(List<Contact> addressBooks)
    {
        Set<Contact> contacts = new HashSet<Contact>();
        
        for(Contact addressBook : addressBooks)
        {
            List<Contact> allContacts = new ArrayList<Contact>();
            allContacts.addAll(contacts);
        }
        return contacts;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please select an option");
        System.out.println("1. Add User");
        System.out.println("2. Remove User");
        System.out.println("3. View User");
        System.out.println("4. Edit User");
        System.out.println("5. Search User");
        String option;
        do{
              option = keyboard.nextLine();
              switch(option)
              {
                  case "1":
                      addContact();
                      break;
                  case "2":
                      deleteContact();
                      break;
                  case "3":
                      viewContacts();
                      break;
                  case "4":
                      editContact();
                      break;
                  case "5":
          //            findContacts();
                      break;
                  default:
                      System.out.println("Please select a valid option");
              }
        }while(!option.equals("1") && !option.equals("2") && !option.equals("3")&& !option.equals("4")&& !option.equals("5"));
            System.out.println();
        
    }
    
}
